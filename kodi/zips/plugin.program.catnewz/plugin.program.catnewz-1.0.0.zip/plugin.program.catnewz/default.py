# -*- coding: utf-8 -*-
"""Catnewz für Kodi – Einstiegspunkt des Plugins (Listen, Lesemodus, Aktionen)."""
import os
import sys

_LIB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

from catnewz import plugin  # noqa: E402

if __name__ == "__main__":
    plugin.run(sys.argv)
