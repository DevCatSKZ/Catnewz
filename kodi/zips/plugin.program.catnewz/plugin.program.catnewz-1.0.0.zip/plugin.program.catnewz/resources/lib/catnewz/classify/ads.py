# -*- coding: utf-8 -*-
"""Port von ``AdDetector`` (Werbe-Erkennung v2, gewichtetes Punktesystem).

score = Link-Signale (Shop-Domain +0.8, Werbe-Pfad +0.6)
      + Text-Signale (Titel-Treffer voll, nur Snippet-Treffer x0.7)
      - Gegen-Signale (Tierheim, Tierschutz …)
Werbung ab score >= THRESHOLD (0.5). Rechnung in float32 wie Kotlin ``Float``.
Sprachauswahl per ``when (language)`` – OHNE lowercase.
"""
from ._rules import as_text, cached, f32, rules, rx_list, select, weighted_list
from .text import normalize

# Konstanten aus AdDetector.score (Programmlogik, nicht in rules.json)
_SHOP_DOMAIN = f32(0.8)
_AD_URL = f32(0.6)
_SNIPPET_FACTOR = f32(0.7)


class _Rules(object):
    __slots__ = ("threshold", "shop_domains", "ad_url", "signals", "counters")


_by_language = {}


def _rules_for(language):
    found = _by_language.get(language)
    if found is None:
        spec = rules()["ads"]
        sig_key, sig_raw = select(spec["signals"], language)
        cnt_key, cnt_raw = select(spec["counters"], language)

        def build(r):
            a = r["ads"]
            out = _Rules()
            out.threshold = f32(a["threshold"])
            out.shop_domains = tuple(a["shopDomains"])
            out.ad_url = rx_list(a["adUrlPatterns"])
            # Kotlin: strongCommon + when (language) { ... } – Reihenfolge zählt
            # (Float-Addition ist nicht assoziativ).
            out.signals = weighted_list(a["commonSignals"]) + weighted_list(sig_raw)
            out.counters = weighted_list(cnt_raw)
            return out

        found = _by_language[language] = cached(("ads", sig_key, cnt_key), build)
    return found


def ad_score(title, snippet, language, link=""):
    """``AdDetector.score(title, snippet, language, link)`` (float32-Wert)."""
    r = _rules_for(as_text(language))
    n_title = normalize(as_text(title))
    n_snippet = normalize(as_text(snippet))
    full = n_title if n_snippet == "" else n_title + " " + n_snippet
    lower_link = as_text(link).lower()

    score = 0.0
    for domain in r.shop_domains:
        if domain in lower_link:
            score = f32(score + _SHOP_DOMAIN)
            break
    for rx in r.ad_url:
        if rx.search(lower_link) is not None:
            score = f32(score + _AD_URL)
            break

    for rx, weight in r.signals:
        if rx.search(n_title) is not None:
            score = f32(score + weight)
        elif rx.search(n_snippet) is not None:
            score = f32(score + f32(weight * _SNIPPET_FACTOR))

    for rx, weight in r.counters:
        if rx.search(full) is not None:
            score = f32(score - weight)
    return score


def is_advertisement(title, snippet, language, link=""):
    """``AdDetector.isAdvertisement(title, snippet, language, link)``."""
    r = _rules_for(as_text(language))
    return ad_score(title, snippet, language, link) >= r.threshold
