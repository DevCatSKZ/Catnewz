# -*- coding: utf-8 -*-
"""Hintergrunddienst: aktualisiert im eingestellten Abstand, ergänzt fehlende
Bilder/Teaser (gedrosselt) und meldet auf Wunsch neue Meldungen – nie während
einer Video-Wiedergabe. Die schwere Arbeit liegt hier, damit das Plugin auch
auf einem Raspberry Pi 3 sofort öffnet."""
import time

import xbmc

from catnewz import kodi, news
from catnewz.kodi import L
from catnewz.store import Store

START_DELAY = 30
TICK = 60
BACKFILL_BATCH = 24
BACKFILL_ROUNDS = 10
BACKFILL_PAUSE = 20


def _cycle(monitor):
    if not kodi.setting_bool("background", True):
        return
    store = Store(kodi.profile_path())
    config = kodi.config()
    interval = max(1, kodi.setting_int("interval", 3)) * 3600
    due = (time.time() - store.data.get("last_refresh", 0) > interval * 0.9
           or store.data.get("language") != config.language
           or store.data.get("region", "") != config.region)
    new_ids = []
    if due:
        if not store.acquire_lock():
            return
        try:
            before = set(store.articles)
            news.refresh(store, config)
            new_ids = [aid for aid in store.articles if aid not in before]
        finally:
            store.release_lock()
        _notify(store, config, new_ids)
    _backfill(store, config, monitor)


def _backfill(store, config, monitor):
    """Bilder/Teaser in Runden nachladen, mit Pausen (Google drosselt sonst).

    Ohne Sperre: das Plugin soll währenddessen jederzeit aktualisieren können;
    gespeichert wird per merge_articles auf den jeweils aktuellen Dateistand."""
    for round_number in range(BACKFILL_ROUNDS):
        if monitor.abortRequested():
            return
        if store.is_locked():
            return  # das Plugin lädt gerade – nächste Runde später
        if round_number:
            store.reload()
        if not news.backfill(store, config, limit=BACKFILL_BATCH, should_stop=monitor.abortRequested):
            return
        if monitor.waitForAbort(BACKFILL_PAUSE):
            return


def _notify(store, config, new_ids):
    if not new_ids or not kodi.setting_bool("notify", False):
        return
    if xbmc.Player().isPlayingVideo():
        return
    visible = set(a["id"] for a in news.visible(store, config))
    fresh = [store.articles[aid] for aid in new_ids if aid in visible]
    if kodi.setting_bool("notify_positive_only", True):
        fresh = [a for a in fresh if store.mood(a) == "POSITIVE"]
        if fresh:
            kodi.notify(L(30054) % len(fresh) if len(fresh) > 1 else fresh[0]["title"])
    elif fresh:
        kodi.notify(L(30055) % len(fresh) if len(fresh) > 1 else fresh[0]["title"])


def run():
    monitor = xbmc.Monitor()
    kodi.log("Hintergrunddienst gestartet")
    if monitor.waitForAbort(START_DELAY):
        return
    while not monitor.abortRequested():
        try:
            _cycle(monitor)
        except Exception as error:  # noqa: BLE001 – Dienst darf nie sterben
            kodi.log("Hintergrund-Aktualisierung fehlgeschlagen: %r" % error, xbmc.LOGWARNING)
        # Alle 10 Minuten prüfen, ob etwas fällig ist (Einstellungen können sich ändern).
        if monitor.waitForAbort(TICK * 10):
            break
