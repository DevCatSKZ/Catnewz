# -*- coding: utf-8 -*-
"""Google-News-Links → Verlags-URL, wie in der App (GoogleNewsDecoder.kt):
alte CBMi…-IDs enthalten die URL; neue brauchen Signatur + Zeitstempel aus der
Artikelseite und Googles eigene Auflösung (batchexecute, RPC Fbv4je).

Google sperrt bei zu vielen Abfragen per Captcha (429) – Aufrufer drosseln,
nach einer Sperre wird hier ``RATE_LIMITED`` gemeldet."""
import base64
import json
import re
import time
from urllib.parse import urlencode

from catnewz import http

BATCH_URL = "https://news.google.com/_/DotsSplashUi/data/batchexecute"
CONSENT_COOKIE = "SOCS=CAI"
RATE_LIMITED = "rate-limited"

_ID_CHARS = re.compile(r"^[A-Za-z0-9_-]+$")
_TS = re.compile(r'data-n-a-ts="(\d+)"')
_SG = re.compile(r'data-n-a-sg="([A-Za-z0-9_-]+)"')

_cooldown_until = [0.0]
_COOLDOWN_SECONDS = 30 * 60


def _raw_id(url):
    tail = url.split("/articles/", 1)[1] if "/articles/" in url else ""
    return tail.split("?", 1)[0].split("/", 1)[0]


def article_id(url):
    raw = _raw_id(url)
    return raw if len(raw) >= 24 and _ID_CHARS.match(raw) else None


def decode_local(url):
    """Alte IDs (Base64-Protobuf mit eingebetteter URL) ohne Netz auflösen."""
    raw = _raw_id(url)
    if len(raw) < 24:
        return None
    try:
        padded = raw.replace("-", "+").replace("_", "/")
        padded += "=" * (-len(padded) % 4)
        data = base64.b64decode(padded)
    except (ValueError, TypeError):
        return None
    index = 0
    while index < len(data) - 12:
        if data[index:index + 4] == b"http":
            end = index
            while end < len(data) and 0x21 <= data[end] <= 0x7E:
                end += 1
            candidate = data[index:end].decode("ascii", "ignore")
            if candidate.startswith(("http://", "https://")) and "google.com" not in candidate:
                return candidate
            index = end
        else:
            index += 1
    return None


def batch_request(article, timestamp, signature):
    inner = ('["garturlreq",[["X","X",["X","X"],null,null,1,1,"US:en",null,1,null,null,null,'
             'null,null,0,1],"X","X",1,[1,1,1],1,1,null,0,0,null,0],"%s",%s,"%s"]'
             % (article, timestamp, signature))
    return json.dumps([[["Fbv4je", inner, None, "generic"]]], separators=(",", ":"))


def parse_batch_response(body):
    try:
        outer = json.loads(body[body.index("["):])
    except (ValueError, IndexError):
        return None
    for entry in outer:
        if not isinstance(entry, list) or len(entry) < 3:
            continue
        if entry[0] != "wrb.fr" or entry[1] != "Fbv4je" or not isinstance(entry[2], str):
            continue
        try:
            payload = json.loads(entry[2])
        except ValueError:
            continue
        if payload and payload[0] == "garturlres" and len(payload) > 1:
            url = payload[1]
            if isinstance(url, str) and url.startswith("http") and "news.google.com" not in url:
                return url
    return None


def _rate_limited(response):
    return response.status == 429 or "google.com/sorry" in (response.url or "")


def cooling_down():
    """Nach einer Google-Sperre 30 Minuten Pause (gilt pro Prozess)."""
    return time.time() < _cooldown_until[0]


def resolve(url):
    """Verlags-URL, ``RATE_LIMITED`` oder None (nicht auflösbar)."""
    local = decode_local(url)
    if local:
        return local
    if cooling_down():
        return RATE_LIMITED
    article = article_id(url)
    if not article:
        return None
    page = http.fetch("https://news.google.com/rss/articles/%s" % article, timeout=12,
                      max_bytes=1500000, headers={"Cookie": CONSENT_COOKIE}, mobile=True)
    if _rate_limited(page):
        _cooldown_until[0] = time.time() + _COOLDOWN_SECONDS
        return RATE_LIMITED
    if not page.ok:
        return None
    text = page.text()
    ts, sg = _TS.search(text), _SG.search(text)
    if not ts or not sg:
        return None
    body = urlencode({"f.req": batch_request(article, ts.group(1), sg.group(1))}).encode("utf-8")
    answer = http.fetch(BATCH_URL, timeout=12, max_bytes=65536, data=body, mobile=True,
                        headers={"Cookie": CONSENT_COOKIE,
                                 "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"})
    if _rate_limited(answer):
        _cooldown_until[0] = time.time() + _COOLDOWN_SECONDS
        return RATE_LIMITED
    if not answer.ok:
        return None
    return parse_batch_response(answer.text())
