# -*- coding: utf-8 -*-
"""Port von ``TopicClassifier``: erste Übereinstimmung in Prioritätsreihenfolge
(ADOPTION > RESCUE > SHELTER > FUNNY > KNOWLEDGE) gewinnt."""
from ._rules import any_match, as_text, cached, rx_list
from .text import normalize

ADOPTION = "ADOPTION"
RESCUE = "RESCUE"
SHELTER = "SHELTER"
FUNNY = "FUNNY"
KNOWLEDGE = "KNOWLEDGE"


def _build(lang):
    def build(r):
        spec = r["topic"]
        # Kotlin: adoption[lang].orEmpty() – fehlende Sprache = leere Liste
        return tuple((topic, rx_list(spec["patterns"][topic].get(lang, ())))
                     for topic in spec["order"])
    return build


def _language(language):
    # Kotlin: if (language in setOf("de", "en", ...)) language else "en"
    # (ohne lowercase – "DE" fällt auf Englisch zurück)
    spec = cached(("topic-languages",), lambda r: (frozenset(r["topic"]["languages"]),
                                                   r["topic"]["fallback"]))
    return language if language in spec[0] else spec[1]


def classify_topic(title, snippet, language):
    """``TopicClassifier.classify(title, snippet, language)`` → Topic-Name oder None."""
    lang = _language(as_text(language))
    rules_for_lang = cached(("topic", lang), _build(lang))
    text = normalize("%s %s" % (as_text(title), as_text(snippet)))
    for topic, regexes in rules_for_lang:
        if any_match(regexes, text):
            return topic
    return None
