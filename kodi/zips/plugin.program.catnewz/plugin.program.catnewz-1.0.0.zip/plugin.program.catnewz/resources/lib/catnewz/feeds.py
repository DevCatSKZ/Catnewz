# -*- coding: utf-8 -*-
"""Feed-Katalog – wie in der App (FeedCatalog.kt): Bing-News-Suchen (Bilder,
Teaser, direkte Links), Katzen-Portale, Mainstream-Feeds mit Katzenfilter und
Google News als Ergänzung. Dazu Regional-Feeds für Stadt/Region."""
from urllib.parse import quote_plus

SUPPORTED_LANGUAGES = ("de", "en", "es", "fr", "it")


class Feed(object):
    __slots__ = ("name", "url", "language", "cat_specific", "regional")

    def __init__(self, name, url, language, cat_specific=False, regional=False):
        self.name = name
        self.url = url
        self.language = language
        self.cat_specific = cat_specific
        self.regional = regional

    @property
    def is_google(self):
        return "news.google.com" in self.url

    def __repr__(self):
        return "Feed(%r)" % self.name


_GOOGLE_LOCALE = {
    "de": ("de", "DE", "DE:de"),
    "en": ("en-US", "US", "US:en"),
    "es": ("es-419", "ES", "ES:es"),
    "fr": ("fr", "FR", "FR:fr"),
    "it": ("it", "IT", "IT:it"),
}
_BING_MARKET = {"de": "de-DE", "en": "en-US", "es": "es-ES", "fr": "fr-FR", "it": "it-IT"}


def google_news(query, language):
    hl, gl, ceid = _GOOGLE_LOCALE.get(language, _GOOGLE_LOCALE["en"])
    return "https://news.google.com/rss/search?q=%s&hl=%s&gl=%s&ceid=%s" % (quote_plus(query), hl, gl, ceid)


def bing_news(query, language, newest_first=False):
    market = _BING_MARKET.get(language, "en-US")
    sort = "&qft=sortbydate%3d%221%22" if newest_first else ""
    return "https://www.bing.com/news/search?q=%s&format=rss&setmkt=%s&count=30%s" % (
        quote_plus(query), market, sort)


def _bing(name, query, language, newest_first=False):
    return Feed(name, bing_news(query, language, newest_first), language, True)


def _google(name, query, language):
    return Feed(name, google_news(query, language), language, True)


def _german():
    de = "de"
    return [
        _bing("Bing: Katze", "Katze", de),
        _bing("Bing: Katze (neu)", "Katze", de, True),
        _bing("Bing: Katzen", "Katzen", de),
        _bing("Bing: Katzen (neu)", "Katzen", de, True),
        _bing("Bing: Kätzchen", "Kätzchen", de),
        _bing("Bing: Katzenbaby", "Katzenbaby", de),
        _bing("Bing: Kater", "Kater Katze", de),
        _bing("Bing: Tierheim Katze", "Tierheim Katze", de),
        _bing("Bing: Tierheim Katze (neu)", "Tierheim Katze", de, True),
        _bing("Bing: Katze gerettet", "Katze gerettet", de),
        _bing("Bing: Katze vermisst", "Katze vermisst", de),
        _bing("Bing: Tierschutz Katze", "Tierschutz Katze", de),
        _bing("Bing: Katze Feuerwehr", "Katze Feuerwehr", de),
        _bing("Bing: Streunerkatze", "Streunerkatze", de),
        _bing("Bing: Katze adoptiert", "Katze adoptiert", de),
        _bing("Bing: Fundkatze", "Fundkatze", de),
        _bing("Bing: Katzenbabys", "Katzenbabys", de),
        _bing("Bing: Katzenschutz", "Katzenschutz", de),
        _bing("Bing: Katze verletzt gerettet", "Katze verletzt gerettet", de),
        _bing("Bing: vermisste Katze gefunden", "vermisste Katze gefunden", de),
        _bing("Bing: Katze Studie", "Katze Studie", de),
        _bing("Bing: Lustige Katze", "lustige Katze", de),
        _bing("Bing: Katze witzig", "Katze witzig", de),
        _google("Google News: Lustige Katze", "lustige Katze when:14d", de),
        Feed("DeineTierwelt Magazin", "https://www.deine-tierwelt.de/magazin/feed/", de),
        Feed("Katzenkram", "https://katzenkram.net/feed/", de, True),
        Feed("n-tv", "https://www.n-tv.de/rss", de),
        Feed("Merkur", "https://www.merkur.de/welt/rssfeed.rdf", de),
        Feed("Stern", "https://www.stern.de/feed/standard/all/", de),
        Feed("RP Online", "https://rp-online.de/feed.rss", de),
        Feed("DerWesten", "https://www.derwesten.de/feed/", de),
        _google("Google News: Katze", "Katze when:7d", de),
        _google("Google News: Katzen", "Katzen when:7d", de),
        _google("Google News: Tierheim Katze", "Tierheim Katze when:7d", de),
    ]


def _english():
    en = "en"
    return [
        _bing("Bing: Cats", "cats", en),
        _bing("Bing: Cats (new)", "cats", en, True),
        _bing("Bing: Kitten", "kitten", en),
        _bing("Bing: Cat rescued", "cat rescued", en),
        _bing("Bing: Shelter cat", "shelter cat", en),
        _bing("Bing: Cat adopted", "cat adopted", en),
        _bing("Bing: Stray cat", "stray cat", en),
        _bing("Bing: Cat breed", "cat breed", en),
        _bing("Bing: Kitten rescue", "kitten rescue", en),
        _bing("Bing: Found cat", "found cat", en),
        _bing("Bing: Cat shelter adoption", "cat shelter adoption", en),
        _bing("Bing: Cat welfare", "cat welfare", en),
        _bing("Bing: Funny cat", "funny cat", en),
        _bing("Bing: Hilarious cat", "hilarious cat", en),
        _bing("Bing: Cat viral video", "cat viral video", en),
        _google("Google News: Funny cat", "funny cat when:14d", en),
        Feed("Love Meow", "https://www.lovemeow.com/feeds/feed.rss", en, True),
        Feed("Katzenworld", "https://katzenworld.co.uk/feed/", en, True),
        Feed("iHeartCats", "https://iheartcats.com/feed/", en, True),
        Feed("Catster", "https://www.catster.com/feed/", en, True),
        Feed("Cattitude Daily", "https://cattitudedaily.com/feed/", en, True),
        Feed("The Purrington Post", "https://www.thepurringtonpost.com/feed/", en, True),
        Feed("Cole & Marmalade", "https://coleandmarmalade.com/feed/", en, True),
        Feed("Modern Cat", "https://moderncat.com/feed/", en, True),
        _google("Google News: Cats", "cats when:7d", en),
        _google("Google News: Kitten", "kitten when:7d", en),
        _google("Google News: Cat rescue", "cat rescue when:7d", en),
        _google("Google News: Shelter cat", "shelter cat when:7d", en),
    ]


def _spanish():
    es = "es"
    return [
        _bing("Bing: Gatos", "gatos", es),
        _bing("Bing: Gatos (nuevo)", "gatos", es, True),
        _bing("Bing: Gatitos", "gatitos", es),
        _bing("Bing: Gato rescatado", "gato rescatado", es),
        _bing("Bing: Refugio gatos", "refugio gatos", es),
        _bing("Bing: Gato adoptado", "gato adoptado", es),
        _bing("Bing: Gatos rescate", "gatos rescate", es),
        _bing("Bing: Protectora gatos", "protectora gatos", es),
        _bing("Bing: Gato callejero", "gato callejero", es),
        _bing("Bing: Gato perdido", "gato perdido", es),
        _bing("Bing: Gatitos rescatados", "gatitos rescatados", es),
        _bing("Bing: Adopción gato", "adopcion gato", es),
        _bing("Bing: Colonia felina", "colonia felina", es),
        _bing("Bing: Gato herido", "gato herido", es),
        _bing("Bing: Gato gracioso", "gato gracioso", es),
        _bing("Bing: Vídeo gato viral", "video gato viral", es),
        _google("Google News: Gato gracioso", "gato gracioso when:14d", es),
        _google("Google News: Gatos", "gatos when:7d", es),
        _google("Google News: Gato rescatado", "gato rescatado when:7d", es),
        _google("Google News: Refugio gatos", "refugio gatos when:7d", es),
    ]


def _french():
    fr = "fr"
    return [
        _bing("Bing: Chats", "chats", fr),
        _bing("Bing: Chats (récent)", "chats", fr, True),
        _bing("Bing: Chat", "chat animal", fr),
        _bing("Bing: Chaton", "chaton", fr),
        _bing("Bing: Chat sauvé", "chat sauvé", fr),
        _bing("Bing: Refuge chat", "refuge chat", fr),
        _bing("Bing: Chat adopté", "chat adopté", fr),
        _bing("Bing: Chat sauvetage", "chat sauvetage", fr),
        _bing("Bing: Refuge chats", "refuge chats", fr),
        _bing("Bing: Chat perdu", "chat perdu", fr),
        _bing("Bing: Chat drôle", "chat drole", fr),
        _bing("Bing: Chat rigolo", "chat rigolo", fr),
        _bing("Bing: Vidéo chat viral", "video chat viral", fr),
        _google("Google News: Chat", "chat when:7d", fr),
        _google("Google News: Chaton", "chaton when:7d", fr),
        _google("Google News: Refuge chat", "refuge chat when:7d", fr),
    ]


def _italian():
    it = "it"
    return [
        _bing("Bing: Gatti", "gatti", it),
        _bing("Bing: Gatti (recente)", "gatti", it, True),
        _bing("Bing: Gatto", "gatto animale", it),
        _bing("Bing: Gattino", "gattino", it),
        _bing("Bing: Gatto salvato", "gatto salvato", it),
        _bing("Bing: Rifugio gatti", "rifugio gatti", it),
        _bing("Bing: Gatto adottato", "gatto adottato", it),
        _bing("Bing: Gatti salvati", "gatti salvati", it),
        _bing("Bing: Gatto smarrito", "gatto smarrito", it),
        _bing("Bing: Gatto abbandonato", "gatto abbandonato", it),
        _bing("Bing: Adozione gatto", "adozione gatto", it),
        _bing("Bing: Gattini salvati", "gattini salvati", it),
        _bing("Bing: Gatto buffo", "gatto buffo", it),
        _bing("Bing: Video gatto virale", "video gatto virale", it),
        _google("Google News: Gatto divertente", "gatto divertente when:14d", it),
        Feed("Kodami", "https://www.kodami.it/feed/", it),
        Feed("TuttoZampe", "https://www.tuttozampe.com/feed/", it),
        Feed("PetsBlog", "https://www.petsblog.it/feed/", it),
        _google("Google News: Gatti", "gatti when:7d", it),
        _google("Google News: Gatto", "gatto when:7d", it),
    ]


_CATALOG = {"de": _german, "en": _english, "es": _spanish, "fr": _french, "it": _italian}

_REGIONAL_TERMS = {
    "de": ("Katze", "Tierheim"),
    "es": ("gato", "protectora animales"),
    "fr": ("chat", "refuge animaux"),
    "it": ("gatto", "gattile"),
    "en": ("cat", "animal shelter"),
}


def built_in(language):
    return _CATALOG.get(language, _english)()


def regional(region, language):
    """Katzen- und Tierheim-Suchen für Stadt/Region über Bing UND Google News."""
    name = (region or "").strip()
    if not name:
        return []
    cat, shelter = _REGIONAL_TERMS.get(language, _REGIONAL_TERMS["en"])
    return [
        Feed("Regional: %s %s" % (cat, name), bing_news("%s %s" % (cat, name), language), language, True, True),
        Feed("Regional: %s %s" % (shelter, name), bing_news("%s %s %s" % (shelter, name, cat), language),
             language, True, True),
        Feed("Regional: %s %s (Google)" % (cat, name), google_news("%s %s when:30d" % (cat, name), language),
             language, True, True),
        Feed("Regional: %s %s (Google)" % (shelter, name), google_news("%s %s when:30d" % (shelter, name), language),
             language, False, True),
    ]


def active(language, region="", use_google=True):
    feeds = built_in(language) + regional(region, language)
    if not use_google:
        feeds = [f for f in feeds if not f.is_google]
    return feeds
