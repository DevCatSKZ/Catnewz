# -*- coding: utf-8 -*-
"""Catnewz-Plugin: Menüs, Listen, Lesemodus und Aktionen.

Nur Standard-Listen und -Dialoge von Kodi (plus ein eigenes, mitgeliefertes
Lese-Fenster) – funktioniert mit jedem Skin und auf jeder Plattform. Jede
Liste ist auch als Widget nutzbar, z. B.
``plugin://plugin.program.catnewz/?action=list&mood=POSITIVE``."""
import time
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from catnewz import kodi, news, reader, rss
from catnewz.kodi import L
from catnewz.store import Store

PAGE_SIZE = 50
MOODS = ("POSITIVE", "NEUTRAL", "NEGATIVE")
TOPICS = ("ADOPTION", "RESCUE", "SHELTER", "FUNNY", "KNOWLEDGE")

S = {
    "all": 30000, "POSITIVE": 30001, "NEUTRAL": 30002, "NEGATIVE": 30003, "topics": 30004,
    "ADOPTION": 30005, "RESCUE": 30006, "SHELTER": 30007, "FUNNY": 30008, "KNOWLEDGE": 30009,
    "region": 30010, "saved": 30011, "history": 30012, "search": 30013, "stats": 30014,
    "refresh": 30015, "settings": 30016, "more": 30017, "new": 30018, "n_new": 30019,
    "loading": 30020, "loaded_new": 30021, "loaded_none": 30022, "load_failed": 30023,
    "nothing": 30024, "no_saved": 30025, "bookmark": 30026, "unbookmark": 30027,
    "mute_source": 30028, "less_topic": 30029, "not_cat": 30030, "fix_mood": 30031,
    "loading_article": 30032, "no_fulltext": 30033, "bookmarked": 30034, "muted": 30035,
    "hidden": 30036, "paywall": 30037, "ad": 30038, "local": 30039, "also": 30040,
    "original": 30041, "reader_hint": 30042, "search_term": 30043, "mood_set": 30044,
    "updated": 30045, "stats_week": 30046, "stats_sources": 30047, "new_since": 30049,
    "reset_muted": 30051, "reset_notcat": 30052, "cache_cleared": 30053,
}

MENU_ICONS = {
    "all": "all.png", "POSITIVE": "positive.png", "NEUTRAL": "neutral.png", "NEGATIVE": "negative.png",
    "topics": "topics.png", "ADOPTION": "adoption.png", "RESCUE": "rescue.png", "SHELTER": "shelter.png",
    "FUNNY": "funny.png", "KNOWLEDGE": "knowledge.png", "region": "region.png", "saved": "saved.png",
    "history": "history.png", "search": "search.png", "stats": "stats.png", "refresh": "refresh.png",
    "settings": "settings.png",
}


class Plugin(object):
    def __init__(self, argv):
        self.base = argv[0]
        self.handle = int(argv[1]) if len(argv) > 1 and argv[1].lstrip("-").isdigit() else -1
        self.params = dict(parse_qsl(argv[2][1:])) if len(argv) > 2 and argv[2] else {}
        self.config = kodi.config()
        self.store = Store(kodi.profile_path())

    # ------------------------------------------------------------ Hilfen

    def url(self, **params):
        return "%s?%s" % (self.base, urlencode(params))

    def run_url(self, **params):
        return "RunPlugin(%s)" % self.url(**params)

    def ensure_fresh(self, force=False):
        """Bei Bedarf aktualisieren (alter Stand, andere Sprache/Region)."""
        data = self.store.data
        age = time.time() - data.get("last_refresh", 0)
        cache_seconds = max(5, kodi.setting_int("cache_minutes", 30)) * 60
        stale = (force or not data["articles"] or age > cache_seconds
                 or data.get("language") != self.config.language
                 or data.get("region", "") != self.config.region)
        if not stale:
            return None
        if not self.store.acquire_lock():
            # Der Hintergrunddienst lädt gerade – kurz warten, dann dessen Stand nehmen.
            for _ in range(40):
                if not self.store.is_locked():
                    break
                xbmc.sleep(250)
            self.store.reload()
            return None
        progress = xbmcgui.DialogProgressBG()
        progress.create("Catnewz", L(S["loading"]))
        try:
            def report(done, total):
                progress.update(int(done * 100 / max(1, total)), "Catnewz", L(S["loading"]))
            new_count, ok, _total = news.refresh(self.store, self.config, report)
        except Exception as error:  # noqa: BLE001 – Liste trotzdem zeigen
            kodi.log("Aktualisierung fehlgeschlagen: %r" % error, xbmc.LOGWARNING)
            new_count, ok = 0, 0
        finally:
            progress.close()
            self.store.release_lock()
        if not ok:
            kodi.notify(L(S["load_failed"]))
        return new_count

    def folder(self, label, url, icon, plot="", is_folder=True, context=None):
        item = xbmcgui.ListItem(label=label, offscreen=True)
        art = kodi.media(MENU_ICONS.get(icon, "icon.png"))
        item.setArt({"icon": art, "thumb": art, "fanart": kodi.media("fanart.jpg")})
        if plot:
            _set_info(item, title=label, plot=plot)
        if context:
            item.addContextMenuItems(context)
        return url, item, is_folder

    def finish(self, items, content="files", sort=False):
        if items:
            xbmcplugin.addDirectoryItems(self.handle, items, len(items))
        xbmcplugin.setContent(self.handle, content)
        if sort:
            # Masken: eigene Beschriftung (%L, mit Stimmungspunkt und NEU) statt Kodis
            # Standard „Titel“ (%T); rechts die Quelle (%U = Studio).
            for method in (xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_TITLE,
                           xbmcplugin.SORT_METHOD_DATEADDED):
                xbmcplugin.addSortMethod(self.handle, method, labelMask="%L", label2Mask="%U")
        xbmcplugin.endOfDirectory(self.handle, succeeded=True, cacheToDisc=False)

    # ------------------------------------------------------------ Menüs

    def root(self):
        self.ensure_fresh()
        boundary = self.store.touch_visit()
        visible = news.visible(self.store, self.config)
        new_count = sum(1 for a in visible if boundary and a.get("fetched", 0) > boundary)
        per_mood = {m: 0 for m in MOODS}
        for article in visible:
            per_mood[self.store.mood(article)] = per_mood.get(self.store.mood(article), 0) + 1
        updated = kodi.time_label(self.store.data.get("last_refresh", 0))

        def count_label(key, count, extra=""):
            return "%s  [COLOR %s](%d)[/COLOR]%s" % (L(S[key]), kodi.MUTED, count, extra)

        items = []
        new_suffix = "  [COLOR %s]%s[/COLOR]" % (kodi.ACCENT, L(S["n_new"]) % new_count) if new_count else ""
        items.append(self.folder(count_label("all", len(visible), new_suffix), self.url(action="list"), "all",
                                 L(S["updated"]) % updated))
        for mood in MOODS:
            label = "[COLOR %s]%s[/COLOR]  [COLOR %s](%d)[/COLOR]" % (
                kodi.MOOD_COLORS[mood], L(S[mood]), kodi.MUTED, per_mood.get(mood, 0))
            items.append(self.folder(label, self.url(action="list", mood=mood), mood))
        items.append(self.folder(L(S["topics"]), self.url(action="topics"), "topics"))
        if self.config.region:
            local = sum(1 for a in visible if a.get("local"))
            label = "%s  [COLOR %s](%d)[/COLOR]" % (L(S["region"]) % self.config.region, kodi.MUTED, local)
            items.append(self.folder(label, self.url(action="list", local="1"), "region"))
        items.append(self.folder(count_label("saved", len(self.store.user["bookmarks"])),
                                 self.url(action="list", saved="1"), "saved"))
        items.append(self.folder(L(S["history"]), self.url(action="list", history="1"), "history"))
        items.append(self.folder(L(S["search"]), self.url(action="search"), "search", is_folder=False))
        items.append(self.folder(L(S["stats"]), self.url(action="stats"), "stats", is_folder=False))
        items.append(self.folder(L(S["refresh"]), self.url(action="refresh"), "refresh",
                                 L(S["updated"]) % updated, is_folder=False))
        items.append(self.folder(L(S["settings"]), self.url(action="settings"), "settings", is_folder=False))
        self.finish(items)

    def topics(self):
        self.ensure_fresh()
        items = []
        for topic in TOPICS:
            count = len(news.visible(self.store, self.config, topic=topic))
            label = "%s  [COLOR %s](%d)[/COLOR]" % (L(S[topic]), kodi.MUTED, count)
            items.append(self.folder(label, self.url(action="list", topic=topic), topic))
        self.finish(items)

    # ------------------------------------------------------------ Listen

    def article_list(self):
        params = self.params
        page = int(params.get("page", "0") or 0)
        personal = params.get("saved") == "1" or params.get("history") == "1"
        if not personal:
            self.ensure_fresh()
        boundary = self.store.user.get("visit_boundary", 0)
        if params.get("saved") == "1":
            articles = news.sort_articles(list(self.store.user["bookmarks"].values()), news.SORT_PUBLISHED)
        elif params.get("history") == "1":
            read = self.store.user["read"]
            articles = [self.store.article(aid) for aid, _ in sorted(read.items(), key=lambda kv: kv[1], reverse=True)]
            articles = [a for a in articles if a]
        else:
            articles = news.visible(self.store, self.config, mood=params.get("mood"), topic=params.get("topic"),
                                    local=params.get("local") == "1", query=params.get("query"))
        if not articles:
            kodi.notify(L(S["no_saved"]) if params.get("saved") == "1" else L(S["nothing"]))
        start = page * PAGE_SIZE
        items = [self.article_item(a, boundary) for a in articles[start:start + PAGE_SIZE]]
        if len(articles) > start + PAGE_SIZE:
            more = dict(params)
            more["page"] = str(page + 1)
            items.append(self.folder("%s  [COLOR %s](%d)[/COLOR]" % (L(S["more"]), kodi.MUTED, len(articles) - start - PAGE_SIZE),
                                     self.url(**more), "all"))
        self.finish(items, content="videos", sort=True)

    def article_item(self, article, boundary):
        mood = self.store.mood(article)
        is_new = bool(boundary) and article.get("fetched", 0) > boundary and not self.store.is_read(article["id"])
        prefix = "[COLOR %s]●[/COLOR] " % kodi.MOOD_COLORS.get(mood, kodi.GOLD)
        if is_new:
            prefix += "[COLOR %s][B]%s[/B][/COLOR] " % (kodi.ACCENT, L(S["new"]))
        when = kodi.time_label(article.get("published"))
        item = xbmcgui.ListItem(label=prefix + article["title"], label2="%s · %s" % (article.get("source", ""), when),
                                offscreen=True)
        thumb = rss.bing_sized(article.get("image"), 640, 360) or kodi.media("placeholder_%s.jpg" % mood.lower())
        fanart = rss.bing_sized(article.get("image"), 1280, 720) or kodi.media("fanart.jpg")
        item.setArt({"thumb": thumb, "icon": thumb, "landscape": thumb, "fanart": fanart})
        _set_info(item, title=article["title"], plot=self.plot(article, mood, is_new),
                  date_added=kodi.date_added(article.get("fetched")), premiered=article.get("published"),
                  playcount=1 if self.store.is_read(article["id"]) else 0, studio=article.get("source", ""))
        item.setProperty("IsPlayable", "false")
        item.addContextMenuItems(self.context_menu(article))
        return self.url(action="read", id=article["id"]), item, False

    def plot(self, article, mood, is_new):
        badges = []
        if is_new:
            badges.append("[COLOR %s]%s[/COLOR]" % (kodi.ACCENT, L(S["new"])))
        if article.get("topic"):
            badges.append("[COLOR %s]%s[/COLOR]" % (kodi.ACCENT if article["topic"] == "ADOPTION" else kodi.VIOLET,
                                                    L(S[article["topic"]])))
        if article.get("local"):
            badges.append("[COLOR %s]%s[/COLOR]" % (kodi.GOLD, L(S["local"])))
        if article.get("paywall"):
            badges.append("[COLOR FFFF6B7A]%s[/COLOR]" % L(S["paywall"]))
        lines = ["[B]%s[/B]" % article["title"]]
        if article.get("snippet"):
            lines.append(article["snippet"])
        lines.append("")
        lines.append("[COLOR %s]%s · %s[/COLOR]" % (kodi.MUTED, article.get("source", ""),
                                                    kodi.time_label(article.get("published"))))
        lines.append("[COLOR %s]● %s[/COLOR]%s" % (kodi.MOOD_COLORS.get(mood), L(S[mood]),
                                                       ("   " + " · ".join(badges)) if badges else ""))
        return "[CR]".join(lines)

    def context_menu(self, article):
        aid = article["id"]
        menu = []
        if self.store.is_bookmarked(aid):
            menu.append((L(S["unbookmark"]), self.run_url(action="bookmark", id=aid, on="0")))
        else:
            menu.append((L(S["bookmark"]), self.run_url(action="bookmark", id=aid, on="1")))
        if article.get("source"):
            menu.append((L(S["mute_source"]) % article["source"], self.run_url(action="mute_source", id=aid)))
        if article.get("topic"):
            menu.append((L(S["less_topic"]) % L(S[article["topic"]]), self.run_url(action="mute_topic", id=aid)))
        menu.append((L(S["not_cat"]), self.run_url(action="not_cat", id=aid)))
        menu.append((L(S["fix_mood"]), self.run_url(action="mood", id=aid)))
        menu.append((L(S["refresh"]), self.run_url(action="refresh")))
        return menu

    # ------------------------------------------------------------ Lesemodus

    def read(self):
        article = self.store.article(self.params.get("id", ""))
        if not article:
            return
        content = self.store.cached_reader(article["id"])
        if content is None:
            busy = xbmcgui.DialogProgress()
            busy.create("Catnewz", L(S["loading_article"]))
            try:
                content = reader.load(article["link"])
            finally:
                busy.close()
            if content.get("url") and content["url"] != article["link"] and "news.google.com" in article["link"]:
                article["link"] = content["url"]
                article["google"] = False
                self.store.save_articles()
            if content.get("blocks"):
                self.store.cache_reader(article["id"], content)
        newly_read = not self.store.is_read(article["id"])
        self.store.mark_read(article["id"])
        show_reader(article, content, self.store.mood(article))
        if newly_read:
            xbmc.executebuiltin("Container.Refresh")

    # ------------------------------------------------------------ Aktionen

    def act_bookmark(self):
        article = self.store.article(self.params.get("id", ""))
        if article:
            on = self.params.get("on") == "1"
            self.store.set_bookmark(article, on)
            if on:
                kodi.notify(L(S["bookmarked"]))
            xbmc.executebuiltin("Container.Refresh")

    def act_mute_source(self):
        article = self.store.article(self.params.get("id", ""))
        if article and article.get("source"):
            self.store.set_source_muted(article["source"], True)
            kodi.notify(L(S["muted"]) % article["source"])
            xbmc.executebuiltin("Container.Refresh")

    def act_mute_topic(self):
        article = self.store.article(self.params.get("id", ""))
        if article and article.get("topic"):
            self.store.set_topic_muted(article["topic"], True)
            kodi.notify(L(S["muted"]) % L(S[article["topic"]]))
            xbmc.executebuiltin("Container.Refresh")

    def act_not_cat(self):
        article = self.store.article(self.params.get("id", ""))
        if not article:
            return
        self.store.add_not_cat(article["title"])
        from catnewz import dedupe
        reported = dedupe.tokens(article["title"])
        for aid in [k for k, a in self.store.articles.items()
                    if k == article["id"] or dedupe.similar(dedupe.tokens(a["title"]), reported)]:
            if not self.store.is_bookmarked(aid):
                self.store.articles.pop(aid, None)
        self.store.save_articles()
        kodi.notify(L(S["hidden"]))
        xbmc.executebuiltin("Container.Refresh")

    def act_mood(self):
        article = self.store.article(self.params.get("id", ""))
        if not article:
            return
        current = self.store.mood(article)
        labels = [("✓ " if m == current else "") + L(S[m]) for m in MOODS]
        choice = xbmcgui.Dialog().select(L(S["fix_mood"]), labels, preselect=MOODS.index(current))
        if choice >= 0:
            self.store.set_mood(article["id"], MOODS[choice])
            kodi.notify(L(S["mood_set"]) % L(S[MOODS[choice]]))
            xbmc.executebuiltin("Container.Refresh")

    def act_search(self):
        term = xbmcgui.Dialog().input(L(S["search_term"]))
        if term and term.strip():
            xbmc.executebuiltin("Container.Update(%s)" % self.url(action="list", query=term.strip()))

    def act_refresh(self):
        new_count = self.ensure_fresh(force=True)
        if new_count is not None:
            kodi.notify(L(S["loaded_new"]) % new_count if new_count else L(S["loaded_none"]))
        xbmc.executebuiltin("Container.Refresh")

    def act_stats(self):
        self.ensure_fresh()
        week = time.time() - 7 * 86400
        recent = [a for a in news.visible(self.store, self.config) if a.get("published", 0) >= week]
        moods = {m: 0 for m in MOODS}
        sources, topics = {}, {}
        for article in recent:
            moods[self.store.mood(article)] += 1
            sources[article.get("source", "")] = sources.get(article.get("source", ""), 0) + 1
            if article.get("topic"):
                topics[article["topic"]] = topics.get(article["topic"], 0) + 1
        total = max(1, len(recent))
        lines = ["[B]%s[/B]  (%d)" % (L(S["stats_week"]), len(recent)), ""]
        for mood in MOODS:
            share = moods[mood] * 100 // total
            bar = "█" * max(1, share // 4) if moods[mood] else ""
            lines.append("[COLOR %s]%-10s %s[/COLOR]  %d  (%d %%)" % (kodi.MOOD_COLORS[mood], L(S[mood]), bar,
                                                                     moods[mood], share))
        lines += ["", "[B]%s[/B]" % L(S["topics"])]
        for topic in TOPICS:
            lines.append("%s: %d" % (L(S[topic]), topics.get(topic, 0)))
        lines += ["", "[B]%s[/B]" % L(S["stats_sources"])]
        for source, count in sorted(sources.items(), key=lambda kv: kv[1], reverse=True)[:10]:
            lines.append("%s: %d" % (source, count))
        xbmcgui.Dialog().textviewer("Catnewz – %s" % L(S["stats"]), "\n".join(lines))

    def act_settings(self):
        kodi.addon().openSettings()

    def act_reset_muted(self):
        self.store.user["muted_sources"] = []
        self.store.user["muted_topics"] = []
        self.store.save_user()
        kodi.notify(L(S["reset_muted"]))

    def act_reset_notcat(self):
        self.store.user["not_cat"] = []
        self.store.save_user()
        kodi.notify(L(S["reset_notcat"]))

    def act_clear_cache(self):
        self.store.data["articles"] = {}
        self.store.data["last_refresh"] = 0
        self.store.save_articles()
        self.store.user["reader"] = {}
        self.store.save_user()
        kodi.notify(L(S["cache_cleared"]))

    # ------------------------------------------------------------ Router

    def dispatch(self):
        action = self.params.get("action", "")
        routes = {
            "": self.root, "topics": self.topics, "list": self.article_list, "read": self.read,
            "bookmark": self.act_bookmark, "mute_source": self.act_mute_source, "mute_topic": self.act_mute_topic,
            "not_cat": self.act_not_cat, "mood": self.act_mood, "search": self.act_search,
            "refresh": self.act_refresh, "stats": self.act_stats, "settings": self.act_settings,
            "reset_muted": self.act_reset_muted, "reset_notcat": self.act_reset_notcat,
            "clear_cache": self.act_clear_cache,
        }
        routes.get(action, self.root)()


def _set_info(item, title="", plot="", date_added=None, premiered=None, playcount=None, studio=""):
    """Video-Infos für Kodi 20+ (InfoTagVideo) mit Rückfall auf setInfo (Kodi 19)."""
    premiered_text = time.strftime("%Y-%m-%d", time.localtime(premiered)) if premiered else None
    try:
        tag = item.getVideoInfoTag()
    except AttributeError:
        tag = None
    if tag is not None and hasattr(tag, "setPlot"):
        tag.setMediaType("video")
        tag.setTitle(title)
        tag.setPlot(plot)
        if date_added:
            tag.setDateAdded(date_added)
        if premiered_text:
            tag.setPremiered(premiered_text)
        if playcount is not None:
            tag.setPlaycount(playcount)
        if studio:
            tag.setStudios([studio])
        return
    info = {"mediatype": "video", "title": title, "plot": plot}
    if date_added:
        info["dateadded"] = date_added
    if premiered_text:
        info["premiered"] = premiered_text
    if playcount is not None:
        info["playcount"] = playcount
    if studio:
        info["studio"] = studio
    item.setInfo("video", info)


def show_reader(article, content, mood):
    """Eigenes Lese-Fenster (mit Bild); Rückfall auf Kodis Textansicht."""
    try:
        from catnewz import window
        window.show(article, content, mood)
    except Exception as error:  # noqa: BLE001 – Textansicht geht immer
        kodi.log("Lese-Fenster nicht verfügbar (%r) – Textansicht" % error, xbmc.LOGWARNING)
        xbmcgui.Dialog().textviewer(article["title"], reader_text(article, content, mood))


def reader_text(article, content, mood):
    lines = ["[COLOR %s]%s · %s[/COLOR]" % (kodi.MUTED, article.get("source", ""),
                                            kodi.time_label(article.get("published"))),
             "[COLOR %s]● %s[/COLOR]" % (kodi.MOOD_COLORS.get(mood), L(S[mood])), ""]
    blocks = (content or {}).get("blocks") or []
    if blocks:
        for kind, text in blocks:
            lines.append("[B][COLOR %s]%s[/COLOR][/B]" % (kodi.ACCENT, text) if kind == "h" else text)
            lines.append("")
    else:
        lines.append("[I]%s[/I]" % L(S["no_fulltext"]))
        lines.append("")
        lines.append(article.get("snippet") or "")
        lines.append("")
    also = article.get("also") or []
    if also:
        lines.append("[COLOR %s]%s: %s[/COLOR]" % (kodi.MUTED, L(S["also"]), ", ".join(a[0] for a in also)))
    lines.append("[COLOR %s]%s[/COLOR]" % (kodi.MUTED, L(S["original"]) % ((content or {}).get("url") or article["link"])))
    return "\n".join(lines)


def run(argv):
    Plugin(argv).dispatch()
