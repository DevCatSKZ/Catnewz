# -*- coding: utf-8 -*-
"""Eigenes Lese-Fenster im Catnewz-Holo-Look (Bild, Stimmung, Quelle, Volltext).

Das Fenster bringt sein Layout und seine Grafiken selbst mit
(resources/skins/Default) – es läuft daher mit jedem Skin. Inhalte kommen als
Fenster-Eigenschaften, das XML zeigt sie über $INFO[Window.Property(…)] an."""
import xbmcgui

from catnewz import kodi, rss
from catnewz.kodi import L

XML_FILE = "script-catnewz-reader.xml"
CLOSE_ACTIONS = (9, 10, 13, 92)  # ParentDir, PreviousMenu, Stop, NavBack
SCROLLBAR_ID = 31


class ReaderWindow(xbmcgui.WindowXMLDialog):
    def onInit(self):
        try:
            self.setFocusId(SCROLLBAR_ID)
        except RuntimeError:
            pass

    def onAction(self, action):
        if action.getId() in CLOSE_ACTIONS:
            self.close()


def _body(article, content):
    from catnewz.plugin import S
    blocks = (content or {}).get("blocks") or []
    parts = []
    if blocks:
        for kind, text in blocks:
            parts.append("[B][COLOR %s]%s[/COLOR][/B]" % (kodi.ACCENT, text) if kind == "h" else text)
    else:
        parts.append("[I][COLOR %s]%s[/COLOR][/I]" % (kodi.MUTED, L(S["no_fulltext"])))
        if article.get("snippet"):
            parts.append(article["snippet"])
    also = article.get("also") or []
    if also:
        parts.append("[COLOR %s]%s: %s[/COLOR]" % (kodi.MUTED, L(S["also"]), ", ".join(a[0] for a in also)))
    return "[CR][CR]".join(parts)


def show(article, content, mood):
    from catnewz.plugin import S
    window = ReaderWindow(XML_FILE, kodi.addon_path(), "Default", "1080i")
    image = (content or {}).get("image") or rss.bing_sized(article.get("image"), 1280, 720) or ""
    badges = []
    if article.get("topic"):
        badges.append(L(S[article["topic"]]))
    if article.get("local"):
        badges.append(L(S["local"]))
    if article.get("paywall"):
        badges.append(L(S["paywall"]))
    url = (content or {}).get("url") or article["link"]
    host = url.split("/")[2] if "://" in url else url
    properties = {
        "title": article["title"],
        "image": image,
        "mood": "[COLOR %s]●  %s[/COLOR]" % (kodi.MOOD_COLORS.get(mood, kodi.GOLD), L(S[mood])),
        "meta": "%s  ·  %s" % (article.get("source", ""), kodi.time_label(article.get("published"))),
        "badges": "  ·  ".join(badges),
        "body": _body(article, content),
        "original": L(S["original"]) % host.replace("www.", ""),
        "hint": L(S["reader_hint"]),
    }
    for key, value in properties.items():
        window.setProperty(key, value)
    window.doModal()
    del window
