# -*- coding: utf-8 -*-
"""Nachrichten-Pipeline wie in der App: Feeds parallel laden → Katzen-Relevanz
→ „Keine Katzen-Meldung“ → Duplikate (mit Bild-/Teaser-Rettung und „Auch
berichtet von“) → Stimmung, Thema, Werbung, Paywall, Region → speichern.
Dazu das Nachladen fehlender Bilder/Teaser und die Auswahl für die Listen."""
import hashlib
import re
import time
from concurrent.futures import ThreadPoolExecutor

from catnewz import classify, dedupe, feeds, google, http, reader, rss

DAY = 86400
MAX_ARTICLES = 900
FEED_WORKERS = 8
PREVIEW_WORKERS = 4
PREVIEW_RETRY = DAY
GOOGLE_SPACING = 1.0

SORT_NEWEST, SORT_PUBLISHED, SORT_MOOD = "newest", "published", "mood"


class Config(object):
    """Einstellungen, die die Pipeline braucht (aus Kodi oder Tests)."""

    def __init__(self, language="de", region="", hide_ads=True, hide_paywall=False, max_age_days=14,
                 sort=SORT_NEWEST, use_google=True):
        self.language = language if language in feeds.SUPPORTED_LANGUAGES else "en"
        self.region = (region or "").strip()
        self.hide_ads = hide_ads
        self.hide_paywall = hide_paywall
        self.max_age_days = max(1, min(30, int(max_age_days)))
        self.sort = sort
        self.use_google = use_google


def article_id(guid):
    return hashlib.sha1((guid or "").encode("utf-8")).hexdigest()[:16]


class RegionMatcher(object):
    """Nennt die Meldung die Region als eigenes, großgeschriebenes Wort?"""

    def __init__(self, region):
        name = (region or "").strip()
        self.pattern = re.compile(r"(?<![^\W_])" + re.escape(name) + r"(?![^\W_])", re.I) if len(name) >= 3 else None

    def mentions(self, *texts):
        if not self.pattern:
            return False
        for text in texts:
            for match in self.pattern.finditer(text or ""):
                if match.group(0)[:1].isupper():
                    return True
        return False


def _fetch_feed(feed):
    response = http.fetch(feed.url, timeout=15, max_bytes=4 * 1024 * 1024,
                          accept="application/rss+xml,application/xml,text/xml,*/*;q=0.8")
    if not response.ok:
        return feed, None
    return feed, response.text()


def _score(article, language):
    score, sentiment = classify.analyze_sentiment(article["title"], article.get("snippet", ""), language)
    article["score"] = round(float(score), 4)
    article["sentiment"] = sentiment


def refresh(store, config, progress=None):
    """Lädt alle Feeds. Gibt (neue Meldungen, Feeds ok, Feeds gesamt) zurück."""
    language = config.language
    feed_list = feeds.active(language, config.region, config.use_google)
    if store.data.get("language") != language:
        store.data["articles"] = {}  # andere Sprache → neu aufbauen
    store.data["language"] = language
    region_changed = store.data.get("region", "") != config.region
    store.data["region"] = config.region

    results = {}
    done = [0]
    with ThreadPoolExecutor(max_workers=FEED_WORKERS) as pool:
        for feed, text in pool.map(_fetch_feed, feed_list):
            results[feed.url] = text
            done[0] += 1
            if progress:
                progress(done[0], len(feed_list))

    articles = store.articles
    now = int(time.time())
    min_published = now - config.max_age_days * DAY
    not_cat = [dedupe.tokens(title) for title in store.user.get("not_cat", [])]
    if not_cat:  # auch Gemeldetes, das ein paralleler Lauf wieder gespeichert hat
        bookmarks = store.user.get("bookmarks", {})
        for aid in [k for k, a in articles.items() if k not in bookmarks
                    and any(dedupe.similar(dedupe.tokens(a["title"]), reported) for reported in not_cat)]:
            articles.pop(aid, None)
    session = dedupe.Session()
    for existing in sorted(articles.values(), key=lambda a: a.get("fetched", 0)):
        session.add(existing["title"], existing["link"], existing["id"])
    region = RegionMatcher(config.region)
    if region_changed:
        for existing in articles.values():
            existing["local"] = region.mentions(existing["title"], existing.get("snippet", ""))

    new_count, ok_feeds = 0, 0
    for feed in feed_list:  # Katalog-Reihenfolge: Bing gewinnt bei Duplikaten
        text = results.get(feed.url)
        if text is None:
            continue
        ok_feeds += 1
        for item in rss.parse(text, feed.name):
            if item["published"] < min_published:
                continue
            if not classify.is_relevant(item["title"], item["snippet"], language, feed.cat_specific):
                continue
            toks = dedupe.tokens(item["title"])
            if any(dedupe.similar(toks, reported) for reported in not_cat):
                continue
            aid = article_id(item["guid"])
            known = articles.get(aid)
            if known is not None:
                if feed.regional:
                    known["local"] = True
                continue
            original_id = session.check_and_add(item["title"], item["link"], aid)
            if original_id is not None:
                original = articles.get(original_id)
                if original is not None:
                    _merge_duplicate(original, item, feed, language, store)
                continue
            link = item["link"]
            article = {
                "id": aid,
                "title": item["title"],
                "snippet": item["snippet"],
                "link": link,
                "image": item["image"],
                "source": item["source"],
                "published": min(item["published"], now),
                "fetched": now,
                "topic": classify.classify_topic(item["title"], item["snippet"], language),
                "ad": classify.is_advertisement(item["title"], item["snippet"], language, link),
                "paywall": classify.is_paywalled(link, item["title"]),
                "local": feed.regional or region.mentions(item["title"], item["snippet"]),
                "google": "news.google.com" in link,
                "also": [],
                "preview_at": 0,
            }
            _score(article, language)
            articles[aid] = article
            new_count += 1

    # Aufräumen: zu alt, dann auf die neuesten MAX_ARTICLES begrenzen
    for aid in [k for k, a in articles.items() if a.get("published", 0) < min_published]:
        articles.pop(aid, None)
    if len(articles) > MAX_ARTICLES:
        keep = sorted(articles.values(), key=lambda a: (a.get("fetched", 0), a.get("published", 0)), reverse=True)
        store.data["articles"] = dict((a["id"], a) for a in keep[:MAX_ARTICLES])
    if ok_feeds:
        store.data["last_refresh"] = now
    store.save_articles()
    return new_count, ok_feeds, len(feed_list)


def _merge_duplicate(original, item, feed, language, store):
    """Bild/Teaser des Duplikats retten, Quelle unter „Auch berichtet von“ vermerken."""
    changed_text = False
    if not original.get("image") and item.get("image"):
        original["image"] = item["image"]
    if not original.get("snippet") and item.get("snippet"):
        original["snippet"] = item["snippet"]
        changed_text = True
    if feed.regional:
        original["local"] = True
    also = original.setdefault("also", [])
    if item["source"] and item["source"].lower() != original.get("source", "").lower() \
            and all(item["source"].lower() != entry[0].lower() for entry in also) and len(also) < 8:
        also.append([item["source"], item["link"]])
    if changed_text and original["id"] not in store.user.get("moods", {}):
        _score(original, language)


BACKFILL_FIELDS = ("link", "google", "paywall", "image", "snippet", "topic", "score", "sentiment", "preview_at")


def backfill(store, config, limit=24, should_stop=None):
    """Fehlende Bilder/Teaser nachladen (Google-Links vorher auflösen, gedrosselt).

    Gibt die Zahl der bearbeiteten Meldungen zurück (0 = nichts mehr zu tun).
    Während einer Google-Sperre bleiben Google-Meldungen für später liegen."""
    now = int(time.time())
    language = config.language
    skip_google = google.cooling_down()
    candidates = [a for a in store.articles.values()
                  if (not a.get("image") or not a.get("snippet")) and now - a.get("preview_at", 0) > PREVIEW_RETRY
                  and not (skip_google and "news.google.com" in a["link"])]
    candidates.sort(key=lambda a: (a.get("fetched", 0), a.get("published", 0)), reverse=True)
    candidates = candidates[:limit]
    if not candidates:
        return 0

    attempted = []
    for article in candidates:  # Google nacheinander mit Abstand – sonst Captcha fürs ganze Netz
        if should_stop and should_stop():
            break
        if "news.google.com" in article["link"]:
            if skip_google:
                continue
            resolved = google.resolve(article["link"])
            if resolved == google.RATE_LIMITED:
                skip_google = True  # nicht als versucht markieren – nach der Pause erneut
                continue
            if resolved:
                article["link"] = resolved
                article["google"] = False
                article["paywall"] = article.get("paywall") or classify.is_paywalled(resolved, article["title"])
            time.sleep(GOOGLE_SPACING)
        elif "msn.com" in article["link"]:
            article["link"] = reader.resolve_msn(article["link"])
        article["preview_at"] = now
        attempted.append(article)

    pending = [a for a in attempted if "news.google.com" not in a["link"]]

    def work(article):
        if should_stop and should_stop():
            return article, None
        return article, reader.preview(article["link"])

    with ThreadPoolExecutor(max_workers=PREVIEW_WORKERS) as pool:
        for article, page in pool.map(work, pending):
            if not page:
                continue
            changed_text = False
            if not article.get("image") and page.get("image"):
                article["image"] = page["image"]
            if not article.get("snippet") and page.get("description"):
                article["snippet"] = page["description"]
                changed_text = True
                article["topic"] = article.get("topic") or classify.classify_topic(
                    article["title"], article["snippet"], language)
            if classify.paywall_in_html(page.get("html", "")):
                article["paywall"] = True
            if changed_text and article["id"] not in store.user.get("moods", {}):
                _score(article, language)
    store.merge_articles(dict((a["id"], dict((k, a.get(k)) for k in BACKFILL_FIELDS)) for a in attempted))
    return len(attempted)


# ------------------------------------------------------------------ Auswahl

def visible(store, config, mood=None, topic=None, local=False, query=None, personal=False):
    """Artikel für eine Liste – mit allen Filtern, „Weniger davon“ und Sortierung."""
    user = store.user
    muted_sources = set(s.lower() for s in user.get("muted_sources", []))
    muted_topics = set(user.get("muted_topics", []))
    needle = (query or "").strip().lower()
    result = []
    for article in store.articles.values():
        if not personal:
            if config.hide_ads and article.get("ad"):
                continue
            if config.hide_paywall and article.get("paywall"):
                continue
            if article.get("source", "").lower() in muted_sources:
                continue
            if article.get("topic") in muted_topics and article.get("topic") != topic:
                continue
        if mood and store.mood(article) != mood:
            continue
        if topic and article.get("topic") != topic:
            continue
        if local and not article.get("local"):
            continue
        if needle and needle not in article["title"].lower() and needle not in article.get("snippet", "").lower():
            continue
        result.append(article)
    return sort_articles(result, config.sort, store)


def sort_articles(articles, sort, store=None):
    if sort == SORT_PUBLISHED:
        return sorted(articles, key=lambda a: a.get("published", 0), reverse=True)
    if sort == SORT_MOOD:
        def mood_score(a):
            override = store.user.get("moods", {}).get(a["id"]) if store else None
            value = {"POSITIVE": 0.6, "NEUTRAL": 0.0, "NEGATIVE": -0.6}.get(override, a.get("score", 0.0))
            return (value, a.get("published", 0))
        return sorted(articles, key=mood_score, reverse=True)
    return sorted(articles, key=lambda a: (a.get("fetched", 0), a.get("published", 0)), reverse=True)


def counts(store, config):
    """Anzahl je Stimmung (für die Menüs)."""
    total = {"POSITIVE": 0, "NEUTRAL": 0, "NEGATIVE": 0}
    for article in visible(store, config):
        total[store.mood(article)] = total.get(store.mood(article), 0) + 1
    return total
