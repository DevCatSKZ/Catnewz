# -*- coding: utf-8 -*-
"""Kodi-Anbindung (Kodi 19 Matrix … 22): Einstellungen, Texte, Pfade,
Meldungen. Alles Kodi-Spezifische liegt hier, damit der Rest testbar bleibt."""
import time

import xbmc
import xbmcaddon
import xbmcgui

from catnewz import http, news

ADDON_ID = "plugin.program.catnewz"

ACCENT = "FF2DE1C2"
VIOLET = "FFA08CFF"
GOLD = "FFFFC24B"
MUTED = "FF9AA9A6"
MOOD_COLORS = {"POSITIVE": "FF3EE68F", "NEUTRAL": "FFFFC24B", "NEGATIVE": "FFFF6B7A"}


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def translate_path(path):
    try:
        import xbmcvfs
        return xbmcvfs.translatePath(path)
    except (ImportError, AttributeError):  # Kodi < 19
        return xbmc.translatePath(path)


def addon_path():
    return translate_path(addon().getAddonInfo("path"))


def profile_path():
    return translate_path(addon().getAddonInfo("profile"))


def media(name):
    return "%s/resources/media/%s" % (addon_path().rstrip("/\\").replace("\\", "/"), name)


def L(string_id):
    return addon().getLocalizedString(string_id)


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[Catnewz] %s" % message, level)


def _setting(kind, key, default):
    a = addon()
    try:
        if kind == "bool":
            return a.getSettingBool(key)
        if kind == "int":
            return a.getSettingInt(key)
        return a.getSettingString(key)
    except (RuntimeError, TypeError, AttributeError):
        raw = a.getSetting(key)
        if raw == "":
            return default
        if kind == "bool":
            return raw.lower() == "true"
        if kind == "int":
            try:
                return int(float(raw))
            except ValueError:
                return default
        return raw


def setting_bool(key, default=False):
    return _setting("bool", key, default)


def setting_int(key, default=0):
    return _setting("int", key, default)


def setting_str(key, default=""):
    return _setting("str", key, default) or default


def news_language():
    chosen = setting_str("language", "auto")
    if chosen in ("de", "en", "es", "fr", "it"):
        return chosen
    try:
        kodi_language = xbmc.getLanguage(xbmc.ISO_639_1) or ""
    except Exception:  # noqa: BLE001
        kodi_language = ""
    kodi_language = kodi_language.lower()[:2]
    return kodi_language if kodi_language in ("de", "en", "es", "fr", "it") else "en"


def config():
    language = news_language()
    http.set_language(language)
    return news.Config(
        language=language,
        region=setting_str("region", ""),
        hide_ads=setting_bool("hide_ads", True),
        hide_paywall=setting_bool("hide_paywall", False),
        max_age_days=setting_int("max_age", 14),
        sort=setting_str("sort", news.SORT_NEWEST),
        use_google=setting_bool("use_google", True),
    )


def notify(message, heading="Catnewz", milliseconds=4000, icon=None):
    xbmcgui.Dialog().notification(heading, message, icon or media("icon.png"), milliseconds, False)


def time_label(timestamp):
    """Uhrzeit (heute) oder Datum – im Format der Kodi-Regionseinstellungen."""
    if not timestamp:
        return ""
    moment = time.localtime(timestamp)
    today = time.localtime()
    try:
        time_format = xbmc.getRegion("time").replace(":%S", "").strip() or "%H:%M"
        date_format = xbmc.getRegion("dateshort") or "%d.%m.%Y"
    except Exception:  # noqa: BLE001
        time_format, date_format = "%H:%M", "%d.%m.%Y"
    if moment.tm_yday == today.tm_yday and moment.tm_year == today.tm_year:
        return time.strftime(time_format, moment)
    return time.strftime(date_format, moment)


def date_added(timestamp):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(timestamp or 0))
