# -*- coding: utf-8 -*-
"""HTTP mit der Standardbibliothek: Zeitlimits, gedeckelte Bodies, gzip,
Zeichensatz-Erkennung. Läuft auf jedem Kodi (RPi/LibreELEC, Android, Windows, Linux)."""
import re
import socket
import urllib.error
import urllib.request
import zlib

DESKTOP_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36")
MOBILE_UA = ("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) "
             "Chrome/125.0 Mobile Safari/537.36")

_CHARSET_HEADER = re.compile(r"charset=([\w\-:.]+)", re.I)
_CHARSET_META = re.compile(br"""<meta[^>]+charset=["']?([\w\-:.]+)""", re.I)
_CHARSET_XML = re.compile(br"""<\?xml[^>]+encoding=["']([\w\-:.]+)""", re.I)


class Response(object):
    def __init__(self, status, url, body, headers):
        self.status = status
        self.url = url
        self.body = body
        self.headers = headers

    @property
    def ok(self):
        return 200 <= self.status < 300

    def text(self):
        return decode(self.body, self.headers.get("Content-Type", ""))


def decode(body, content_type=""):
    """Zeichensatz: Header → BOM/XML/Meta → UTF-8 (Fehler werden ersetzt)."""
    if body.startswith(b"\xef\xbb\xbf"):
        return body[3:].decode("utf-8", "replace")
    charset = None
    match = _CHARSET_HEADER.search(content_type or "")
    if match:
        charset = match.group(1)
    if not charset:
        head = body[:4096]
        match = _CHARSET_XML.search(head) or _CHARSET_META.search(head)
        if match:
            charset = match.group(1).decode("ascii", "ignore")
    for candidate in (charset, "utf-8"):
        if not candidate:
            continue
        try:
            return body.decode(candidate)
        except (LookupError, UnicodeDecodeError):
            continue
    return body.decode("utf-8", "replace")


def _read_capped(stream, max_bytes):
    chunks = []
    total = 0
    while total < max_bytes:
        chunk = stream.read(min(65536, max_bytes - total))
        if not chunk:
            break
        chunks.append(chunk)
        total += len(chunk)
    return b"".join(chunks)


MAX_DECOMPRESSED = 8 * 1024 * 1024
ACCEPT_LANGUAGE = ["de-DE,de;q=0.9,en;q=0.8"]
_ACCEPT_LANGUAGES = {
    "de": "de-DE,de;q=0.9,en;q=0.8", "en": "en-US,en;q=0.9", "es": "es-ES,es;q=0.9,en;q=0.8",
    "fr": "fr-FR,fr;q=0.9,en;q=0.8", "it": "it-IT,it;q=0.9,en;q=0.8",
}


def set_language(language):
    """Accept-Language passend zur Nachrichtensprache (Verlage liefern sonst teils Deutsch)."""
    ACCEPT_LANGUAGE[0] = _ACCEPT_LANGUAGES.get(language, _ACCEPT_LANGUAGES["en"])


def _decompress(body, encoding):
    """gzip/deflate – auch abgeschnittene Antworten (max_bytes) liefern lesbaren Anfang."""
    encoding = (encoding or "").lower()
    if "gzip" in encoding:
        attempts = (16 + zlib.MAX_WBITS,)
    elif "deflate" in encoding:
        attempts = (zlib.MAX_WBITS, -zlib.MAX_WBITS)
    else:
        return body
    for wbits in attempts:
        try:
            return zlib.decompressobj(wbits).decompress(body, MAX_DECOMPRESSED)
        except zlib.error:
            continue
    return body


def fetch(url, timeout=15, max_bytes=4 * 1024 * 1024, headers=None, data=None,
          mobile=False, accept="text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"):
    """GET (oder POST mit ``data``). Wirft nie: Netzfehler → Status 0."""
    request_headers = {
        "User-Agent": MOBILE_UA if mobile else DESKTOP_UA,
        "Accept": accept,
        "Accept-Language": ACCEPT_LANGUAGE[0],
        "Accept-Encoding": "gzip, deflate",
    }
    if headers:
        request_headers.update(headers)
    request = urllib.request.Request(url, data=data, headers=request_headers)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = _read_capped(response, max_bytes)
            body = _decompress(raw, response.headers.get("Content-Encoding"))
            return Response(response.status, response.geturl(), body, dict(response.headers))
    except urllib.error.HTTPError as error:
        try:
            body = _read_capped(error, 65536)
        except Exception:  # noqa: BLE001 – Fehlerseiten sind egal
            body = b""
        return Response(error.code, error.geturl() or url, body, dict(error.headers or {}))
    except (urllib.error.URLError, socket.timeout, OSError, ValueError):
        return Response(0, url, b"", {})
