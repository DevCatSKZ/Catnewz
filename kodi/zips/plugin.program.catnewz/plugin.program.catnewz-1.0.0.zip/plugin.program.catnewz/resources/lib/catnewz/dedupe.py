# -*- coding: utf-8 -*-
"""Duplikat-Erkennung: dieselbe Meldung aus mehreren Quellen nur einmal.
Gleicher Link oder sehr ähnliche Titel (Wortmengen nach Normalisierung,
Stoppwörtern und einfachem Stemming). Mit Wort-Index statt Vergleich jeder
mit jedem – auch auf einem Raspberry Pi 3 flott."""
import re
import unicodedata

_STOP = set("""
der die das den dem des ein eine einer einen einem und oder aber mit von vom zum zur im in am an auf aus
für fuer bei nach vor über ueber unter durch ist sind war wird werden wurde hat haben sich nicht noch auch
nur wie was wer wo so als dass es er sie ihr ihre sein seine man jetzt hier dort mehr sehr ganz schon
the a an and or but with from for of to in on at by is are was were be been has have had it its this that
these those as not no new how why what when who will can after before over into out up
el la los las un una y o con de del en por para es son que se su sus al lo
le la les un une et ou avec de du des en au aux pour par est sont qui que se sa son ses ce cette
il lo la i gli le un una e o con di del della dei in per da su che si suo sua è sono al alla
katze katzen kater kätzchen katzchen cat cats kitten kittens gato gatos gata chat chats chaton gatto gatti
""".split())

_SUFFIXES = ("innen", "ungen", "chen", "lein", "ern", "en", "er", "es", "e", "s", "n")
_WORD = re.compile(r"[a-z0-9]+")
_SOURCE_SUFFIX = re.compile(r"\s+[-–—|]\s+[^-–—|]{2,48}$")


def _fold(text):
    text = (text or "").lower().replace("ß", "ss")
    decomposed = unicodedata.normalize("NFD", text)
    return "".join(ch for ch in decomposed if unicodedata.category(ch) != "Mn")


def _stem(token):
    if len(token) < 5:
        return token
    for suffix in _SUFFIXES:
        if token.endswith(suffix) and len(token) - len(suffix) >= 4:
            return token[: -len(suffix)]
    return token


def tokens(title):
    text = _SOURCE_SUFFIX.sub("", _fold(title))
    return frozenset(_stem(word) for word in _WORD.findall(text) if len(word) >= 3 and word not in _STOP)


def normalize_link(link):
    return (link or "").lower().strip().split("?", 1)[0].split("#", 1)[0].rstrip("/")


def similar(a, b):
    if len(a) < 3 or len(b) < 3:
        return False
    common = len(a & b)
    if common < 3:
        return False
    jaccard = common / float(len(a | b))
    containment = common / float(min(len(a), len(b)))
    return jaccard >= 0.55 or (containment >= 0.8 and common >= 4)


class Session(object):
    """Bekannte Meldungen; ``check_and_add`` liefert die ID des Originals oder None."""

    def __init__(self):
        self._links = {}
        self._entries = []  # (tokens, id)
        self._index = {}    # token -> [positions]

    def add(self, title, link, article_id):
        nlink = normalize_link(link)
        if nlink:
            self._links.setdefault(nlink, article_id)
        toks = tokens(title)
        position = len(self._entries)
        self._entries.append((toks, article_id))
        for token in toks:
            self._index.setdefault(token, []).append(position)

    def find(self, title, link):
        nlink = normalize_link(link)
        if nlink and nlink in self._links:
            return self._links[nlink]
        toks = tokens(title)
        candidates = set()
        for token in toks:
            candidates.update(self._index.get(token, ()))
        for position in sorted(candidates):
            other, other_id = self._entries[position]
            if similar(toks, other):
                return other_id
        return None

    def check_and_add(self, title, link, article_id):
        original = self.find(title, link)
        if original is None:
            self.add(title, link, article_id)
        return original
