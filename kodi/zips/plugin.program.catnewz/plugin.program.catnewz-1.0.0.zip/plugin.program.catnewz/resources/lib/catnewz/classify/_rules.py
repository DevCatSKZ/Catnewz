# -*- coding: utf-8 -*-
"""Gemeinsame Infrastruktur der Klassifizierer.

* ``rules()`` lädt die generierte ``rules.json`` erst beim ersten Gebrauch
  (Kodi startet pro Klick einen frischen Interpreter – der Import bleibt billig).
* ``cached()`` kompiliert Musterlisten lazy pro Sprache und hält sie fest.
* ``f32()`` bildet Kotlin-``Float`` (IEEE-754 binary32) exakt nach: jede
  Operation wird in double gerechnet und auf float32 gerundet – für +, -, *, /
  zweier float32-Werte ist das bitgenau dasselbe Ergebnis wie auf der JVM.

Regex-Semantik: Kotlins ``RegexCompat.compile`` = Muster wie geschrieben mit
IGNORE_CASE (Android/ICU: ``\\b``/``\\w`` Unicode-basiert). Python ``re`` mit
str-Mustern ist ebenfalls Unicode-basiert; daher ``re.IGNORECASE`` ohne
Umschreiben der Muster. ``Regex(...)`` ohne Option → keine Flags.
"""
import os
import re
import struct
import threading

RULES_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "rules.json")

# Fingerabdrücke der Kotlin-Logik (fun-Deklarationen pro Datei), gegen die
# dieser Python-Port geschrieben wurde. tools/export_rules.py schreibt den
# aktuellen Stand nach rules.json["logic"]; tests/test_classify.py vergleicht.
# Weicht ein Wert ab, hat sich die App-LOGIK geändert → Port anpassen, dann
# hier den neuen Wert eintragen.
PORTED_LOGIC = {
    "TextNormalizer.kt": "57f5ac2ef7bce38f",
    "RegexCompat.kt": "5333bbe151994731",
    "SentimentLexicon.kt": "e73c8531aa2a7387",
    "SpanishLexicon.kt": "e3b0c44298fc1c14",
    "FrenchLexicon.kt": "e3b0c44298fc1c14",
    "ItalianLexicon.kt": "e3b0c44298fc1c14",
    "SentimentEngine.kt": "4965f30dafb6a832",
    "TopicClassifier.kt": "97ed4160096de9a9",
    "CatRelevance.kt": "b3086fb694c11d6f",
    "AdDetector.kt": "df1112ccd40d3e4f",
    "PaywallDetector.kt": "5f427405c7f2a40e",
}

# Kotlin Char.isWhitespace() (JVM/Android): Character.isWhitespace || isSpaceChar
# = \t \n \x0b \f \r \x1c-\x1f + Unicode Zs/Zl/Zp (inkl. NBSP U+00A0/U+2007/U+202F).
# Grundlage für String.trim() und isBlank().
KOTLIN_WS = (
    "\t\n\x0b\x0c\r\x1c\x1d\x1e\x1f"
    "              "
    "    　"
)
_NON_BLANK = re.compile("[^" + re.escape(KOTLIN_WS) + "]")

_F32 = struct.Struct("<f")
_lock = threading.RLock()
_rules = None
_cache = {}
_compiled = {}


def f32(x):
    """Rundet auf den nächsten float32-Wert (Kotlin Float)."""
    return _F32.unpack(_F32.pack(x))[0]


def coerce_in(x, lo, hi):
    """Kotlin Float.coerceIn(lo, hi)."""
    if x < lo:
        return lo
    if x > hi:
        return hi
    return x


def is_blank(text):
    """Kotlin CharSequence.isBlank()."""
    return _NON_BLANK.search(text) is None


def rules():
    """Die geparste rules.json (einmal pro Interpreter geladen)."""
    global _rules
    data = _rules
    if data is None:
        with _lock:
            if _rules is None:
                import json  # erst hier: hält den Paket-Import schlank
                with open(RULES_PATH, "r", encoding="utf-8") as fh:
                    _rules = json.load(fh)
            data = _rules
    return data


def cached(key, build):
    """Liefert ``build(rules())`` – einmal pro ``key`` gebaut, danach aus dem Cache."""
    try:
        return _cache[key]
    except KeyError:
        pass
    with _lock:
        value = _cache.get(key)
        if value is None:
            value = build(rules())
            _cache[key] = value
        return value


def compile_rx(pattern, ignore_case=True):
    """Kompiliert ein Muster (dedupliziert über alle Listen)."""
    key = (pattern, ignore_case)
    rx = _compiled.get(key)
    if rx is None:
        rx = re.compile(pattern, re.IGNORECASE if ignore_case else 0)
        _compiled[key] = rx
    return rx


def rx_list(patterns):
    """Liste aus ``rx(...)``/``RegexCompat.compile`` (IGNORE_CASE)."""
    return tuple(compile_rx(p) for p in patterns)


def weighted_list(pairs):
    """Liste aus ``wp(...)``/``sig(...)``: (Regex, Float-Gewicht)."""
    return tuple((compile_rx(p), f32(w)) for p, w in pairs)


def plain_rx(spec):
    """``Regex(pattern[, RegexOption.IGNORE_CASE])``."""
    return compile_rx(spec["pattern"], bool(spec["ignoreCase"]))


def select(selector, language):
    """Bildet ``when (language) { "de" -> X ... else -> Y }`` nach.

    Liefert (Schlüssel, Wert); Schlüssel "" steht für den else-Zweig.
    """
    key = language.lower() if selector.get("lowercase") else language
    by_lang = selector["byLanguage"]
    if key in by_lang:
        return key, by_lang[key]
    return "", selector["default"]


def any_match(regexes, text):
    """``list.any { it.containsMatchIn(text) }``."""
    for rx in regexes:
        if rx.search(text) is not None:
            return True
    return False


def as_text(value):
    """Kotlin-Parameter sind non-null; None wird defensiv als "" behandelt."""
    return value if value is not None else ""
