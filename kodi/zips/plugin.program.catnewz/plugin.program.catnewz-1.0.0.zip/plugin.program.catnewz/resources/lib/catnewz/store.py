# -*- coding: utf-8 -*-
"""Speicher im Kodi-Profilordner (addon_data): ``articles.json`` (Meldungen,
neu ladbar) und ``user.json`` (Merkliste, Verlauf, Stummschaltungen,
Korrekturen, Besuch – bleibt). Atomar geschrieben; eine Sperrdatei verhindert,
dass Dienst und Plugin gleichzeitig aktualisieren."""
import json
import os
import time

ARTICLES = "articles.json"
USER = "user.json"
LOCK = "refresh.lock"
LOCK_STALE_SECONDS = 180

MAX_READ = 3000
MAX_READER_CACHE = 40
VISIT_GAP_SECONDS = 30 * 60


def _empty_articles():
    return {"version": 1, "language": None, "region": "", "last_refresh": 0, "articles": {}}


def _empty_user():
    return {
        "version": 1,
        "bookmarks": {},       # id -> Artikel (vollständige Kopie, überlebt jede Bereinigung)
        "read": {},            # id -> Zeitpunkt
        "muted_sources": [],   # Anzeigenamen
        "muted_topics": [],    # ADOPTION/RESCUE/…
        "not_cat": [],         # gemeldete Titel
        "moods": {},           # id -> POSITIVE/NEUTRAL/NEGATIVE (Nutzer-Korrektur)
        "reader": {},          # id -> {"at": ts, "article": {...}} (offline lesbar)
        "last_seen": 0,
        "visit_boundary": 0,
    }


class Store(object):
    def __init__(self, folder):
        self.folder = folder
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        self.data = self._load(ARTICLES, _empty_articles)
        self.user = self._load(USER, _empty_user)

    # ------------------------------------------------------------ Dateien

    def _path(self, name):
        return os.path.join(self.folder, name)

    def _load(self, name, factory):
        try:
            with open(self._path(name), "r", encoding="utf-8") as handle:
                loaded = json.load(handle)
            base = factory()
            base.update(loaded if isinstance(loaded, dict) else {})
            return base
        except (OSError, ValueError):
            return factory()

    def _save(self, name, payload):
        target = self._path(name)
        temp = target + ".tmp"
        with open(temp, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, separators=(",", ":"))
        os.replace(temp, target)

    def save_articles(self):
        self._save(ARTICLES, self.data)

    def save_user(self):
        self._save(USER, self.user)

    def reload(self):
        self.data = self._load(ARTICLES, _empty_articles)
        self.user = self._load(USER, _empty_user)

    def merge_articles(self, updates):
        """Felder je Artikel-ID auf den aktuellen Dateistand anwenden und speichern.

        Für lange Läufe des Dienstes (Nachladen): das Plugin kann inzwischen
        Meldungen entfernt oder geändert haben – das bleibt so erhalten."""
        current = self._load(ARTICLES, _empty_articles)
        if current.get("language") != self.data.get("language"):
            self.data = current  # inzwischen in anderer Sprache neu aufgebaut
            return
        for article_id, fields in updates.items():
            target = current["articles"].get(article_id)
            if target is not None:
                target.update(fields)
        self.data = current
        self.save_articles()

    # ------------------------------------------------------------ Sperre

    def acquire_lock(self):
        path = self._path(LOCK)
        try:
            if os.path.exists(path) and time.time() - os.path.getmtime(path) > LOCK_STALE_SECONDS:
                os.remove(path)
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(os.getpid()).encode("ascii"))
            os.close(fd)
            return True
        except OSError:
            return False

    def release_lock(self):
        try:
            os.remove(self._path(LOCK))
        except OSError:
            pass

    def is_locked(self):
        path = self._path(LOCK)
        return os.path.exists(path) and time.time() - os.path.getmtime(path) <= LOCK_STALE_SECONDS

    # ------------------------------------------------------------ Meldungen

    @property
    def articles(self):
        return self.data["articles"]

    def article(self, article_id):
        return self.articles.get(article_id) or self.user["bookmarks"].get(article_id)

    # ------------------------------------------------------------ Nutzer

    def is_bookmarked(self, article_id):
        return article_id in self.user["bookmarks"]

    def set_bookmark(self, article, on):
        if on:
            self.user["bookmarks"][article["id"]] = dict(article)
        else:
            self.user["bookmarks"].pop(article["id"], None)
        self.save_user()

    def mark_read(self, article_id):
        read = self.user["read"]
        read[article_id] = int(time.time())
        if len(read) > MAX_READ:
            for key, _ in sorted(read.items(), key=lambda kv: kv[1])[: len(read) - MAX_READ]:
                read.pop(key, None)
        self.save_user()

    def is_read(self, article_id):
        return article_id in self.user["read"]

    def mood(self, article):
        return self.user["moods"].get(article["id"]) or article.get("sentiment", "NEUTRAL")

    def set_mood(self, article_id, sentiment):
        self.user["moods"][article_id] = sentiment
        self.save_user()

    def set_source_muted(self, source, muted):
        sources = [s for s in self.user["muted_sources"] if s.lower() != source.lower()]
        if muted:
            sources.append(source)
        self.user["muted_sources"] = sources
        self.save_user()

    def set_topic_muted(self, topic, muted):
        topics = [t for t in self.user["muted_topics"] if t != topic]
        if muted:
            topics.append(topic)
        self.user["muted_topics"] = topics
        self.save_user()

    def add_not_cat(self, title):
        titles = [t for t in self.user["not_cat"] if t != title] + [title]
        self.user["not_cat"] = titles[-200:]
        self.save_user()

    def cache_reader(self, article_id, article):
        cache = self.user["reader"]
        cache[article_id] = {"at": int(time.time()), "article": article}
        if len(cache) > MAX_READER_CACHE:
            for key, _ in sorted(cache.items(), key=lambda kv: kv[1]["at"])[: len(cache) - MAX_READER_CACHE]:
                if key not in self.user["bookmarks"]:
                    cache.pop(key, None)
        self.save_user()

    def cached_reader(self, article_id):
        entry = self.user["reader"].get(article_id)
        return entry["article"] if entry else None

    def touch_visit(self, now=None):
        """Besuch: länger als 30 Min. weg → Grenze für „Neu seit deinem letzten Besuch“."""
        now = now or int(time.time())
        last = self.user.get("last_seen", 0)
        if last and now - last > VISIT_GAP_SECONDS:
            self.user["visit_boundary"] = last
        self.user["last_seen"] = now
        self.save_user()
        return self.user["visit_boundary"]
