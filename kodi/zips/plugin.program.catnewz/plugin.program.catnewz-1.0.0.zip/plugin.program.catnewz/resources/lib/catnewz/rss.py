# -*- coding: utf-8 -*-
"""RSS/Atom-Parser – tolerant wie in der App (RssParser.kt): Feeds sind oft
kein gültiges XML (Bing bettet rohe <img>-Tags und nackte & ein), deshalb
regex-basiert statt ElementTree. Ergebnis: Dicts mit guid, title, snippet,
link, image, source, published (Unix-Sekunden)."""
import calendar
import email.utils
import hashlib
import html
import re
import time
from datetime import datetime, timezone
from urllib.parse import unquote

_ITEM = re.compile(r"<(item|entry)\b[^>]*>(.*?)</\1\s*>", re.S | re.I)
_CDATA = re.compile(r"<!\[CDATA\[(.*?)\]\]>", re.S)
_TAGS = re.compile(r"<[^>]*>")
_SPACES = re.compile(r"\s+")
_URLS = re.compile(r"https?://\S+")
_VIA = re.compile(r"\s+via\s+.{1,40}$", re.I)
_GOOGLE_REAL_LINK = re.compile(r"""<a[^>]+href=["'](https?://(?!news\.google\.com)[^"']+)["']""", re.I)
_BING_URL_PARAM = re.compile(r"[?&]url=([^&]+)")
_IMG_PATTERNS = (
    re.compile(r"""<img[^>]+src\s*=\s*["']([^"']+)["']""", re.I),
    re.compile(r"""<img[^>]+data-src\s*=\s*["']([^"']+)["']""", re.I),
    re.compile(r"""(https?://[^"'\s<>]+\.(?:jpg|jpeg|png|webp)(?:\?[^"'\s<>]*)?)""", re.I),
)
_IMAGE_EXT = re.compile(r".*\.(jpg|jpeg|png|webp|gif)(\?.*)?$", re.I)
_NON_WORD = re.compile(r"[\W_]+", re.U)


def _tag_text(block, name):
    """Text des ersten <name>…</name> (CDATA aufgelöst), sonst ''."""
    match = re.search(r"<%s\b[^>]*>(.*?)</%s\s*>" % (re.escape(name), re.escape(name)), block, re.S | re.I)
    if not match:
        return ""
    text = match.group(1)
    cdata = _CDATA.search(text)
    if cdata:
        return cdata.group(1).strip()
    return html.unescape(text).strip()


def _tag_attr(block, name, attr):
    for match in re.finditer(r"<%s\b([^>]*)/?>" % re.escape(name), block, re.I):
        found = re.search(r"""\b%s\s*=\s*["']([^"']*)["']""" % re.escape(attr), match.group(1), re.I)
        if found:
            yield html.unescape(found.group(1)), match.group(1)


def strip_html(text):
    text = _TAGS.sub(" ", text or "")
    text = html.unescape(html.unescape(text))  # doppelt kodierte Entities ("&amp;uuml;")
    text = text.replace(" ", " ").replace("­", "")
    text = _URLS.sub("", text)
    return _SPACES.sub(" ", text).strip()


def clean_source(source):
    return _VIA.sub("", source or "").strip()


def _comparable(text):
    return _NON_WORD.sub(" ", (text or "").lower()).strip()


def split_google_title(title):
    """„Titel - Quelle" am LETZTEN Trenner trennen, wenn der Rest ein Medienname ist."""
    best_index, best_sep = -1, ""
    for sep in (" - ", " – ", " — ", " | "):
        index = title.rfind(sep)
        if index > best_index:
            best_index, best_sep = index, sep
    if best_index <= 0:
        return None
    clean = title[:best_index].strip()
    source = title[best_index + len(best_sep):].strip()
    if len(clean) < 15 or not source or len(source) > 48 or re.search(r"[!?]", source):
        return None
    return clean, source


def parse_date(value):
    """Unix-Sekunden; RFC 822, ISO 8601 oder Zahl. Unbekannt → jetzt."""
    value = (value or "").strip()
    if not value:
        return int(time.time())
    if value.isdigit() and len(value) >= 3:
        number = int(value)
        return number // 1000 if number > 10 ** 12 else number
    try:
        parsed = email.utils.parsedate_tz(value)
        if parsed:
            return int(email.utils.mktime_tz(parsed))
    except (TypeError, ValueError, OverflowError):
        pass
    iso = value.replace("Z", "+00:00")
    iso = re.sub(r"(\.\d{1,6})\d*", r"\1", iso)  # Python 3.8: max. 6 Nachkommastellen
    iso = re.sub(r"([+-]\d{2})(\d{2})$", r"\1:\2", iso)
    try:
        moment = datetime.fromisoformat(iso)
        if moment.tzinfo is None:
            moment = moment.replace(tzinfo=timezone.utc)
        return int(calendar.timegm(moment.utctimetuple()))
    except ValueError:
        return int(time.time())


def bing_sized(url, width, height):
    """Bing-Thumbnail in Zielgröße, randlos (p=0: kein weißer Auffüll-Rahmen)."""
    if not url or not ("bing.com/th?" in url or "bing.net/th?" in url):
        return url
    url = re.sub(r"([?&])(w|h|c|p)=\d+", "", url)
    url = url.replace("?&", "?")
    sep = "&" if "?" in url else "?"
    return "%s%sw=%d&h=%d&c=14&p=0" % (url, sep, width, height)


def _image_from_html(text):
    for pattern in _IMG_PATTERNS:
        match = pattern.search(text or "")
        if match:
            url = match.group(1)
            if not any(bad in url for bad in ("1x1", "pixel", "spacer")):
                return url
    return ""


def _guid(link, title, source):
    seed = link or ("%s-%s" % (source, title))
    return seed if link else "h-" + hashlib.sha1(seed.encode("utf-8")).hexdigest()[:20]


def parse(xml, source_name):
    items = []
    if not xml:
        return items
    for _, block in _ITEM.findall(xml):
        title = strip_html(_tag_text(block, "title"))
        if not title:
            continue
        description = _tag_text(block, "description") or _tag_text(block, "summary")
        content = _tag_text(block, "content:encoded")
        link = _tag_text(block, "link")
        if not link:
            for href, _ in _tag_attr(block, "link", "href"):
                link = href
                break
        guid = _tag_text(block, "guid") or _tag_text(block, "id")
        published = parse_date(_tag_text(block, "pubDate") or _tag_text(block, "published")
                               or _tag_text(block, "updated") or _tag_text(block, "dc:date"))
        source = _tag_text(block, "News:Source") or _tag_text(block, "source") or source_name

        image = _tag_text(block, "News:Image")
        if not image:
            for name in ("media:content", "media:thumbnail", "enclosure"):
                for url, attrs in _tag_attr(block, name, "url"):
                    is_image = name != "enclosure" or "image/" in attrs or bool(_IMAGE_EXT.match(url))
                    if url and is_image:
                        image = url
                        break
                if image:
                    break
        if not image:
            image = _image_from_html(content) or _image_from_html(description)

        is_google = "news.google.com" in link or "news.google.com" in guid
        if is_google:
            split = split_google_title(title)
            if split:
                title, source = split
            real = _GOOGLE_REAL_LINK.search(description or "")
            if real:
                link = real.group(1)
        snippet = "" if is_google else strip_html(description or content)
        if _comparable(snippet) == _comparable(title):
            snippet = ""

        if "bing.com/news/apiclick" in link:
            encoded = _BING_URL_PARAM.search(link)
            if encoded:
                link = unquote(encoded.group(1))
        if image.startswith("http://"):
            image = "https://" + image[len("http://"):]
        if link.startswith("http://") and "news.google.com" not in link:
            link = "https://" + link[len("http://"):]

        items.append({
            "guid": guid or _guid(link, title, source),
            "title": title,
            "snippet": snippet[:600],
            "link": link,
            "image": image,
            "source": clean_source(strip_html(source)) or source_name,
            "published": published,
        })
    return items
