# -*- coding: utf-8 -*-
"""<meta>-Angaben robust lesen (wie MetaTags.kt): beliebige Reihenfolge,
doppelte/einfache/KEINE Anführungszeichen (minimiertes HTML), relative Bild-URLs."""
import html
import re
from urllib.parse import urljoin

_META = re.compile(r"<meta\b[^>]*>", re.I)
_LINK = re.compile(r"<link\b[^>]*>", re.I)
_ATTR = re.compile(r"""([^\s"'=<>/]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+))""")

IMAGE_KEYS = ("og:image", "og:image:secure_url", "og:image:url", "twitter:image",
              "twitter:image:src", "image_src")
DESCRIPTION_KEYS = ("og:description", "twitter:description", "description")


def _attributes(tag):
    attributes = {}
    for match in _ATTR.finditer(tag):
        name = match.group(1).lower()
        value = match.group(2)
        if value is None:
            value = match.group(3)
        if value is None:
            value = match.group(4)
        attributes.setdefault(name, value)
    return attributes


def parse(text):
    """Schlüssel (property/name/itemprop, klein) → erster nicht-leerer content."""
    result = {}
    for tag in _META.findall(text or ""):
        attributes = _attributes(tag)
        content = (attributes.get("content") or "").strip()
        if not content:
            continue
        for key_attr in ("property", "name", "itemprop"):
            key = (attributes.get(key_attr) or "").strip().lower()
            if key:
                result.setdefault(key, content)
    for tag in _LINK.findall(text or ""):
        attributes = _attributes(tag)
        if (attributes.get("rel") or "").strip().lower() == "image_src" and attributes.get("href"):
            result.setdefault("image_src", attributes["href"].strip())
    return result


def absolute_image(value, page_url=None):
    url = html.unescape((value or "").strip())
    if url.lower().startswith("https://"):
        absolute = url
    elif url.lower().startswith("http://"):
        absolute = "https://" + url[7:]
    elif url.startswith("//"):
        absolute = "https:" + url
    elif url.startswith("/") and page_url:
        absolute = urljoin(page_url, url)
        if absolute.startswith("http://"):
            absolute = "https://" + absolute[7:]
    else:
        return None
    return absolute if absolute.startswith("https://") and len(absolute) > 12 else None


def first_image(meta, page_url=None):
    for key in IMAGE_KEYS:
        if key in meta:
            url = absolute_image(meta[key], page_url)
            if url:
                return url
    return None


def first_description(meta, min_length=30):
    for key in DESCRIPTION_KEYS:
        value = html.unescape(meta.get(key, "")).strip()
        value = re.sub(r"\s+", " ", value)
        if len(value) > min_length:
            return value[:400]
    return None
