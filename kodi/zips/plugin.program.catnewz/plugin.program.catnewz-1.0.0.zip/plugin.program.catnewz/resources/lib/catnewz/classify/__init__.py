# -*- coding: utf-8 -*-
"""Artikel-Klassifikation – reiner Python-Port der Catnewz-App (Kotlin,
``domain/classify``), bitgenau gegen die App geprüft.

Öffentliche API::

    normalize(text) -> str
    analyze_sentiment(title, snippet, language) -> (score: float, "POSITIVE"|"NEUTRAL"|"NEGATIVE")
    classify_topic(title, snippet, language) -> "ADOPTION"|"RESCUE"|"SHELTER"|"FUNNY"|"KNOWLEDGE"|None
    is_relevant(title, snippet, language, cat_specific_source) -> bool
    is_advertisement(title, snippet, language, link) -> bool
    is_paywalled(link, title) -> bool
    paywall_in_html(html) -> bool

Zusätzlich (wie in Kotlin öffentlich): ``ad_score`` und ``is_hard_excluded``.

Die Muster stehen in ``rules.json`` und werden mit ``tools/export_rules.py``
aus den Kotlin-Quellen erzeugt – nie von Hand bearbeiten. Geladen und
kompiliert wird lazy beim ersten Aufruf, pro Sprache und Klassifizierer.

Sprachen: "de", "en", "es", "fr", "it"; unbekannte Codes fallen wie in Kotlin
auf Englisch zurück. Achtung, wie im Original: nur ``analyze_sentiment``
schreibt den Code klein ("DE" → Deutsch); Themen, Relevanz und Werbung
vergleichen exakt ("DE" → Englisch). Codes daher klein übergeben.

Semantik (geprüft gegen JUnit/JVM, Android-ICU und Python 3.8/3.12):
identisch zur JVM-Referenz der App, bis auf JVM-eigene ASCII-Klassen
(``\\s``/``\\b`` in plain ``Regex``) – dort verhält sich der Port wie Android.
Einzige bekannte Abweichung zu Android: ICU faltet bei IGNORE_CASE voll
("ß" == "ss"), Python/JVM nicht – betrifft nur Texte mit ß/ss-Schreibvarianten.
"""
from .ads import ad_score, is_advertisement
from .paywall import is_paywalled, paywall_in_html
from .relevance import is_hard_excluded, is_relevant
from .sentiment import NEGATIVE, NEUTRAL, POSITIVE, analyze_sentiment
from .text import normalize
from .topics import ADOPTION, FUNNY, KNOWLEDGE, RESCUE, SHELTER, classify_topic

TOPICS = (ADOPTION, RESCUE, SHELTER, FUNNY, KNOWLEDGE)
SENTIMENTS = (POSITIVE, NEUTRAL, NEGATIVE)

__all__ = [
    "normalize",
    "analyze_sentiment",
    "classify_topic",
    "is_relevant",
    "is_hard_excluded",
    "is_advertisement",
    "ad_score",
    "is_paywalled",
    "paywall_in_html",
    "POSITIVE", "NEUTRAL", "NEGATIVE", "SENTIMENTS",
    "ADOPTION", "RESCUE", "SHELTER", "FUNNY", "KNOWLEDGE", "TOPICS",
]
